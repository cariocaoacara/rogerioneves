
<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Exercícios 1 </title>
	<style>
		body {margin: 0;}
		.wrap { margin: 0 auto; width: 70%;  }
		p { width: 70%; }
		li {list-style: none;}
	</style>
</head>
<body>
	<div class="wrap">
		<h1>Exercício 1</h1>
		<p>Escreva um programa que declare uma variável inteira e atribua o valor 10 a mesma. Declare uma variável real e atribua para a mesma o valor 20.3. Como saída o programa deverá imprimir, usando as variáveis declaradas, o seguinte resultado:</p>
		<li> a. O valor inteiro é 10. </li>
		<li> b. O valor real é 20.3. </li>
		<h2>Resultado:</h2>

		<?php 
			$inteiro = 10;
			$real = 20.3;
			echo "<li>O valor inteiro é ${inteiro} </li>";
			echo "<li>O valor real é ${real} </li>";
		 ?>
		<h1>Exercício 2</h1>
		<p>Escreva um programa que declare 6 variáveis do tipo caractere e atribua a elas as letras a, l, u, n, o, s. O programa deverá imprimir, usando todas as variáveis declaradas, o seguinte resultado: alunos.</p>
		<h2>Resultado:</h2>
		<?php 
			$a = "a"; $l = "l"; $u = "u"; $n = "n"; $o = "o"; $s = "s";
			echo "<p>".$a.$l.$u.$n.$o.$s."</p>";
			
		 ?>
		<h1>Exercício 3</h1>
		<p>Uma conta telefônica é composta dos seguintes custos:</p>
		<li>Assinatura: R$ 32,00</li>
		<li>Impulsos: R$ 0,09 por impulso que exceder a 90</li>
		<li>Chamadas p/ celular: R$0,35 por impulso</li>
		<p>Escreva um programa que monte a fórmula para calcular o valor da conta para 254 impulsos e 23 chamadas para celular imprimindo o resultado obtido.</p>
		<h2>Resultado:</h2>
		<?php 
			function ContaTelefonica ($impulsos, $chamadas) {
				$valorBase = 32;
				$impulsosExcedentes = $impulsos-90;
				$valorImpulsoExcedente = 0.09;
				$valorChamadaPorImpulso = 0.35;

				$valorChamadas = ($chamadas*$valorChamadaPorImpulso);
				$valorImpulsos =($impulsosExcedentes*$valorImpulsoExcedente);

				return ($valorBase + $valorChamadas + $valorImpulsos);
			}
			echo "O valor final da conta é de R$".ContaTelefonica(254, 23);
		 ?>


		<h1>Exercício 4</h1>
		<p>Fazer um programa que imprima a média dos números 11, 19 e 7.</p>
		<h2>Resultado:</h2>
		<?php 
			$media4 = (11+19+7)/3;
			echo $media4;			
		 ?>


		<h1>Exercício 5</h1>
		<p>Um professor atribui pesos de 1 a 4 para as notas de quatro avaliações.</p>
		<p>A nota é calculada por meio da média ponderada (N1*1 + N2*2 + N3*3 + N4*4) / (1+2+3+4), onde N1 é a nota da primeira avaliação, N2 a da segunda, etc.</p> 
		<p>Um aluno tirou as seguintes notas: 8, 7.5, 10, 9.<br>Faça um programa que calcula e escreva a média deste aluno.</p>
		<h2>Resultado:</h2>
		<?php
			$mediaAluno = (8*1 + 7.5*2 + 10*3 + 9*4) / (1+2+3+4);
			echo "A média do aluno foi de: ${mediaAluno}";
		 ?>


		<h1>Exercício 6</h1>
		<p>Escreva um programa que obtêm dois valores inteiros (variáveis A e B) e apresente as operações de adição, subtração, multiplicação e divisão de A por B.</p> 
		<h2>Resultado:</h2>
		<?php 
			if( 
			!isset($_POST['ex6_int1']) && !isset($_POST['ex6_int2']) ) {
				echo '
					<form method="post">
						<input type="number" name="ex6_int1"><br>
						<input type="number" name="ex6_int2"><br>
						<input type="submit">
					</form>';
			} else{
					$a = intval($_POST['ex6_int1']);
					$b = intval($_POST['ex6_int2']);

					echo "Soma: ${a} + ${b} = ".($a+$b)."<br>";
					echo "Subtração: ${a} - ${b} = ".($a-$b)."<br>";
					echo "Multiplicação: ${a} * ${b} = ".($a*$b)."<br>";
					echo "Divisão: ${a} / ${b} = ".($a/$b)."<br>";
			}
		?>




		<h1>Exercício 7</h1>
		<p>Efetuar a leitura de um número inteiro e apresentar o resultado do quadrado deste número.</p>
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex7_int1']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex7_int1">
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex7_int1']);
			echo "${a}² = ".($a*$a)."<br>";
		}
		 ?>




		<h1>Exercício 8</h1>
		<p>Efetuar a leitura de um número inteiro e apresentar o resultado do cubo deste número.</p>
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex8_int1']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex8_int1">
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex8_int1']);
			echo "${a}³ = ".($a*$a*$a)."<br>";
		}
		 ?>




		<h1>Exercício 9</h1>
		<p>Ler dois números inteiros informados pelo usuário, dividi-los, apresentar o resultado da divisão real desses números, o quadrado do primeiro número e o cubo do segundo número.</p> 
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex9_int1']) && !isset($_POST['ex9_int2']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex9_int1"><br>
				<input type="number" name="ex9_int2"><br>
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex9_int1']);
			$b = intval($_POST['ex9_int2']);
			echo "${a}/${b} = ".($a/$b)."<br>";
			echo "${a}² = ".($a*$a)."<br>";
			echo "${b}³ = ".($a*$a*$a)."<br>";
		}
		?>





		<h1>Exercício 10</h1>
		<p>Efetuar a leitura de um número inteiro e imprimir o resto da divisão (%) deste número por 2.</p> 
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex10_int1']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex10_int1">
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex10_int1']);
			echo "O resto de ${a}/2 = ".($a%2)."<br>";
		}
		?>





		<h1>Exercício 11</h1>
		<p>Ler um número inteiro e imprimir seu sucessor e seu antecessor.</p> 
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex11_int1']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex11_int1">
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex11_int1']);
			echo "Antecessor: ".($a-1)."<br>";
			echo "Sucessor: ".($a+1)."<br>";
		}
		?>






		<h1>Exercício 12</h1>
		<p>Escreva um programa que calcule e mostre o valor da conversão em dólar de um valor lido em real. O programa deverá ler o valor da cotação do dólar e a quantidade de reais.</p> 
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex12_int1']) && !isset($_POST['ex12_int2'])) {
		echo '
			<form method="post">
				<input type="number" name="ex12_int1" placeholder="Valor em R$"><br>
				<input type="number" name="ex12_int2" placeholder="Cotação dólar"><br>
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex12_int1']);
			$b = intval($_POST['ex12_int2']);
			echo "R$${a} equivale a $".($a/$b)."<br>";
		}
		?>






		<h1>Exercício 13</h1>
		<p>Ler um valor e imprimir esse valor com reajuste de 10%.</p> 
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex13_int1']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex13_int1">
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex13_int1']);
			echo ($a*1.1);
		}
		?>






		<h1>Exercício 14</h1>
		<p>Escreva um programa para ler o salário mensal de um funcionário e o percentual de reajuste. Calcular e escrever o valor do novo salário.</p>
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex14_int1']) && !isset($_POST['ex14_int2'])) {
		echo '
			<form method="post">
				<input type="number" name="ex14_int1" placeholder="Salário base"><br>
				<input type="number" name="ex14_int2" placeholder="Reajuste em %"><br>
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex14_int1']);
			$b = intval($_POST['ex14_int2']);
			$b = 1+($b/100);
			echo ($a*$b);
		}
		?>






		<h1>Exercício 15</h1>
		<p>Calcular o salário líquido de uma pessoa. São fornecidos: o valor por hora, o número de horas trabalhadas e o % de desconto do INSS.</p>
		<h2>Resultado:</h2>
		<?php if( !isset($_POST['ex15_int1']) && !isset($_POST['ex15_int2']) && !isset($_POST['ex15_int3']) ) {
		echo '
			<form method="post">
				<input type="number" name="ex15_int1" placeholder="Valor por hora"><br>
				<input type="number" name="ex15_int2" placeholder="Horas trabalhadas"><br>
				<input type="number" name="ex15_int3" placeholder="Desconto em %"><br>
				<input type="submit">
			</form>';
		} else{
			$a = intval($_POST['ex15_int1']);
			$b = intval($_POST['ex15_int2']);
			$c = ( intval($_POST['ex15_int3'])/100 );
			$salario = $a * $b;
			$salarioComDesconto = $salario - ($salario*$c);
			echo "R$".$salarioComDesconto;
		}
		?>
	</div>
</body>
</html>
